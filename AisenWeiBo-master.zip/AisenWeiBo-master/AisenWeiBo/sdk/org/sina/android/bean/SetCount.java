package org.sina.android.bean;

import java.io.Serializable;

public class SetCount implements Serializable {

	private static final long serialVersionUID = -9114308885050692970L;

	private Boolean result;

	public Boolean getResult() {
		return result;
	}

	public void setResult(Boolean result) {
		this.result = result;
	}

}
