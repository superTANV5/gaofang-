package org.aisen.weibo.sina.support.iclass;

import android.app.ActionBar.OnNavigationListener;

public interface IAcNavigation extends OnNavigationListener {

	public int adapterResource();
	
	public int current();
	
}
