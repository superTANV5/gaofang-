package org.aisen.weibo.sina.ui.fragment.base;

import java.io.Serializable;

import com.m.ui.fragment.ACombinationRefreshListFragment;

public abstract class ARefreshProxyFragment<T extends Serializable, Ts extends Serializable> 
							extends ACombinationRefreshListFragment<T, Ts> {

}
